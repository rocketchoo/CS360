package com.example.weightlossapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class IntroActivity extends AppCompatActivity {

    private EditText weightEditText;
    private DBHelper dbHelper;
    private TextView weightTextView;
    private float currentWeight = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        weightEditText = findViewById(R.id.weightEditText);
        Button addWeightButton = findViewById(R.id.addWeightButton);
        Button viewPreviousButton = findViewById(R.id.viewPreviousWeightButton);
        Button backButton = findViewById(R.id.backButton);
        weightTextView = findViewById(R.id.weightTextView);
        dbHelper = new DBHelper(this);

        // Add weight button action
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightInput = weightEditText.getText().toString();
                if (!weightInput.isEmpty()) {
                    currentWeight = Float.parseFloat(weightInput);
                    dbHelper.addWeight(currentWeight, "2024-10-19"); // Example date, update as needed
                    Toast.makeText(IntroActivity.this, "Weight added!", Toast.LENGTH_SHORT).show();
                    weightTextView.setText("Current Weight: " + currentWeight + " kg");
                } else {
                    Toast.makeText(IntroActivity.this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // View previous weight button action
        viewPreviousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = dbHelper.getAllWeights();
                if (cursor.moveToLast()) {
                    float previousWeight = cursor.getFloat(cursor.getColumnIndex("current_weight"));
                    weightTextView.setText("Previous Weight: " + previousWeight + " kg");
                } else {
                    Toast.makeText(IntroActivity.this, "No previous weight recorded.", Toast.LENGTH_SHORT).show();
                }
                cursor.close();
            }
        });

        // Back button action
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to login
            }
        });
    }
}

